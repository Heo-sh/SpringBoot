package com.example.first.dependency;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Computer {

	int ram;
}
